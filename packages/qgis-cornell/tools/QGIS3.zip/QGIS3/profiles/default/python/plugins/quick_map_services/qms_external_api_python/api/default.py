DEFAULT_URL = 'https://qms.nextgis.com/'
DEFAULT_API_VER = 1
